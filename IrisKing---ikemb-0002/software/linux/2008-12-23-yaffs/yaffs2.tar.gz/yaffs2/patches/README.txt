This directory holds patches that are useful for Linux integration.

Right now there is only one patched file, yaffs_mtdif2.c. This has been
patched with a tweaked version of "Sergey's patch" and typically makes a
stock mtd work properly.

